export default { devIndicators: false };
